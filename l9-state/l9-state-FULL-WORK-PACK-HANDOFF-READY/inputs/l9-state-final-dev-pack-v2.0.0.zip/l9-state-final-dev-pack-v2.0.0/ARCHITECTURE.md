# Final Architecture

## 1. Semantic authority

L9 State owns durable **mechanics**, not domain meaning.

It owns:

- tenant/scope/object state identity;
- revision assignment and compare-and-set;
- immutable historical revision records subject to retention;
- durable idempotency/operation receipts;
- optional lease claims and monotonic fencing;
- canonical committed state events and consumer checkpoints;
- tombstone, retained restore, and hard-erasure mechanics;
- provider-neutral read/list/history/recovery semantics;
- schema-binding verification against admitted contracts.

It does not own:

- WorkItem kinds or business lifecycle;
- semantic memory, evidence truth, context selection, reasoning policy, or next actions;
- routing, node discovery, transport signing, or Gate authority;
- client trust grants or profile-derived authorization;
- a generic database/query API;
- Mongo collection/query vocabulary in public contracts;
- repository birth.

## 2. Runtime shape

```text
typed consumer
    |
    | StateClient -> GateClient.execute(...)
    v
Constellation.Gate
    |
    | canonical TransportPacket
    v
Gate_SDK node runtime
    |
    v
l9_state.bindings.gate
    |  derives trusted CallerContext
    |  checks action/idempotency/scope invariants
    v
StateService
    |------> ContractCatalogPort  (admitted schema + retention contract lookup)
    |------> ScopeAuthorizationPort (optional stricter sub-tenant policy; fail closed)
    |
    v
StateStorePort

RetentionExecutor (internal, later unit)
    | consumes externally authorized retention decisions
    +------> StateStorePort.hard_erase(...)
    |
    +------> MongoStateStore (first adapter)
```

No State layer accepts a peer URL. No State layer constructs a TransportPacket by hand for normal application egress. Transport is Gate_SDK-owned.

## 3. Trusted identity and scope

`tenant.org_id`, transport actor/delegation/lineage, action, deadline, and transport idempotency are derived from the validated `TransportPacket`, never from domain payload fields. State defines `tenant_org_id = packet.tenant.org_id` and `principal_ref = packet.tenant.actor`.

Every storage key includes the trusted tenant organization in addition to payload `scope_ref`:

```text
StateKey     = (tenant_org_id, scope_ref, object_id)
OperationKey = (tenant_org_id, scope_ref, operation_id)
ConsumerKey  = (tenant_org_id, scope_ref, consumer_ref)
```

This makes cross-tenant aliasing impossible even when two tenants use identical `scope_ref` or `object_id` values.

## 4. State record model

A current record contains at least:

- StateKey;
- revision;
- state digest;
- immutable `schema_ref` + `schema_digest`;
- lifecycle: `active | tombstoned | erased`;
- retained payload when lifecycle/policy permits;
- created/updated timestamps;
- latest event identity and journal sequence;
- highest fencing token ever issued for this object.

An immutable revision record preserves the exact state representation committed at each revision while retention permits it. Current projection and revision record are committed together.

### Revision law

- `state.create` commits revision `0`.
- Each `state.transition`, `state.tombstone`, `state.restore`, or internal hard-erasure mutation commits `revision + 1`.
- Revisions never decrement, repeat, or reset.
- Deleted/erased object IDs are never reusable in the same tenant/scope.

## 5. Canonical digest law

State payloads are JSON-compatible data. Canonical bytes use RFC 8785 JSON Canonicalization Scheme semantics, then SHA-256 lowercase hex.

`state_digest` covers exactly:

```text
{schema_ref, schema_digest, lifecycle, payload_or_null}
```

`request_digest` covers exactly:

```text
{action, domain_request_without_operation_id}
```

The operation ID is the lookup key, not part of the semantic request digest. Transport hashes remain Gate_SDK-owned and are not substituted for State digests.

## 6. Operation identity and reconciliation

All consequential mutations require a caller-selected stable `operation_id`. On Gate ingress:

`packet.header.idempotency_key MUST equal payload.operation_id`.

Within an operation scope:

- same operation ID + same action + same request digest -> return the exact stored authoritative receipt after current authorization checks; no synthetic `duplicate` receipt/status is created;
- same operation ID + different action or request digest -> `IDEMPOTENCY_COLLISION`, no effect;
- ambiguous transport/storage completion -> reconcile by `OperationKey` before any semantic retry;
- if the authoritative store cannot establish outcome before deadline -> return typed `StateProblem(OUTCOME_UNKNOWN)`; do not persist an unknown receipt.

Operation identity metadata is not TTL-expired automatically in v1.

Unknown commit outcome is never stored as an authoritative receipt. Ambiguity returns `StateProblem(OUTCOME_UNKNOWN)` with the operation ID; later `state.operation.inspect` returns `found` with the exact stored receipt or `not_found` once storage can answer authoritatively. Storage inability is a typed problem, not an inspect result.

## 7. Claims and fences

Claims are coordination, not ownership of business work.

- acquisition validates current expected revision;
- only one active unexpired claim exists per StateKey;
- each successful new acquisition increments the object's monotonic fence;
- renewal keeps the same fence;
- release keeps the fence lineage and makes the claim inactive;
- expiry is logical and uses storage-authoritative server time at commit;
- TTL deletion never defines expiry and never erases fence lineage;
- while an active claim exists, state mutations require exact claim ID + current fence;
- any supplied stale/expired/superseded claim always fails, even if a claimless write would otherwise be legal.

## 8. Atomic commit families

### State mutation transaction

Atomically commit:

1. CAS and active-claim/fence validation;
2. scope-local journal sequence allocation;
3. immutable revision record;
4. current-state projection;
5. canonical StateTransitionEvent;
6. immutable operation receipt.

### Claim transaction

Atomically commit claim/fence state and operation receipt.

### Consumer acknowledgment transaction

Atomically advance only the authorized consumer cursor and commit its operation receipt.

No external call participates in any database transaction.

## 9. Journal and recovery

Every state payload/lifecycle mutation creates one canonical event. A scope has a monotonically increasing `journal_seq`. This is not a global constellation order.

`state.events` is pull-based and authoritative for v1. Cursors are State-issued, opaque to consumers, bound to tenant/scope/consumer and a journal position. Provider resume tokens never enter public contracts.

### Cold resume

1. First `state.list` page captures a `resume_event_cursor` at list start.
2. Consumer enumerates current StateRefs using stable list cursor pages.
3. Consumer calls `state.events` from the captured resume cursor.
4. Replayed later revisions are deduplicated by StateRef revision/event ID.
5. If retention advances beyond the cursor, response is `resync_required`; restart cold resume.

This avoids a second directory database and avoids requiring a globally transactional list snapshot.

## 10. Tombstone, erase, restore

- Tombstone is a normal revisioned mutation and blocks ordinary active reads.
- Tombstone does not automatically destroy historical payload.
- Restore is allowed only from an explicitly retained prior revision, while current lifecycle is `tombstoned`, under CAS and any active fence.
- Hard erasure is retention-policy execution, not an arbitrary client delete. It scrubs retained payloads as policy permits, commits lifecycle `erased`, and preserves minimal identity/revision/fence/operation metadata needed to prevent ABA/replay.
- `hard_erase` is an internal StateStorePort operation invoked only by the retention executor from externally authorized policy decisions. It is not a public Gate action.
- Restore from `erased` is refused in v1.

## 11. Provider boundary

The Mongo adapter is private. Public/domain layers contain no collection names, BSON types, resume tokens, Mongo operators, ObjectIds, or driver exceptions.

Replacement providers must pass the same StateStore conformance suite without changing public State actions or semantics.

## 12. Packaging

Python: `>=3.12` to align with current Gate_SDK family.

One repository may publish one distribution with a contracts/client base and a server extra. Consumer installs must not pull MongoDB drivers unless server functionality is selected.

The typed client is thin: validate domain model -> `GateClient.execute(action, payload, tenant, idempotency_key=operation_id)` -> validate domain result. It does not own signing, packet construction, routing, HTTP, or retries.
