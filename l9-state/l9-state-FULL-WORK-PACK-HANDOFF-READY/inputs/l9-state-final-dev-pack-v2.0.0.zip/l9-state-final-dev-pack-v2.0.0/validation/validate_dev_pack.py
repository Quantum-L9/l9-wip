#!/usr/bin/env python3
from __future__ import annotations
import json, re
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator, ValidationError
from referencing import Registry, Resource
import hashlib

ROOT=Path(__file__).resolve().parents[1]
FORBIDDEN_TEXT=('AG-01','SDK-02','GATE-01','GATE-02','MotorClient','AsyncIOMotorClient','l9-node-template','l9_node_template')

def fail(msg: str) -> bool:
    print('FAIL:', msg)
    return False

def main() -> int:
    ok=True
    files=[p for p in ROOT.rglob('*') if p.is_file()]
    # Structured parse.
    for p in files:
        if p.suffix in {'.yaml','.yml'}:
            try: yaml.safe_load(p.read_text(encoding='utf-8'))
            except Exception as e: ok=fail(f'YAML {p.relative_to(ROOT)}: {e}') and ok
        elif p.suffix=='.json':
            try: json.loads(p.read_text(encoding='utf-8'))
            except Exception as e: ok=fail(f'JSON {p.relative_to(ROOT)}: {e}') and ok
    # No stale campaign/template dependencies. The validator source is excluded so its deny-list is not self-matching.
    corpus='\n'.join(
        p.read_text(encoding='utf-8',errors='ignore') for p in files
        if p != Path(__file__).resolve() and p.suffix in {'.md','.yaml','.yml','.json'}
    )
    for term in FORBIDDEN_TEXT:
        if term in corpus: ok=fail(f'forbidden stale term present: {term}') and ok
    # Public contract provider closure.
    public='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (ROOT/'contracts/schemas').glob('*.json'))
    for term in ('mongo_collection','bson','ObjectId','resumeToken','pymongo'):
        if term.lower() in public.lower(): ok=fail(f'provider leakage in public schemas: {term}') and ok
    # Schema refs and fixtures.
    sroot=ROOT/'contracts/schemas'; schemas={}
    for p in sorted(sroot.glob('*.json')):
        d=json.loads(p.read_text()); Draft202012Validator.check_schema(d); schemas[d['$id']]=d
    for d in schemas.values():
        for ref in re.findall(r'urn:l9:state:[A-Za-z0-9]+:1\.0',json.dumps(d)):
            if ref not in schemas: ok=fail(f'unresolved schema ref {ref}') and ok
    registry=Registry().with_resources((uri,Resource.from_contents(doc)) for uri,doc in schemas.items())
    cases={
      'create_valid.json':('StateCreateRequest',True),
      'create_provider_field_invalid.json':('StateCreateRequest',False),
      'transition_valid.json':('StateTransitionRequest',True),
      'transition_claim_without_fence_invalid.json':('StateTransitionRequest',False),
      'state_receipt_valid.json':('StateReceipt',True),
      'state_receipt_missing_event_invalid.json':('StateReceipt',False),
      'claim_receipt_valid.json':('StateClaimReceipt',True),
      'claim_receipt_missing_fence_invalid.json':('StateClaimReceipt',False),
    }
    for fx,(name,should) in cases.items():
        doc=json.loads((ROOT/'fixtures'/fx).read_text()); sch=schemas[f'urn:l9:state:{name}:1.0']
        try:
            Draft202012Validator(sch,registry=registry).validate(doc); valid=True
        except ValidationError: valid=False
        if valid!=should: ok=fail(f'fixture {fx} validity {valid} expected {should}') and ok
    # Receipt identity law: no synthetic duplicate status.
    for schema_name in ('StateReceipt','StateClaimReceipt','StateAckReceipt'):
        enum=schemas[f'urn:l9:state:{schema_name}:1.0']['properties']['status']['enum']
        if 'duplicate' in enum: ok=fail(f'{schema_name} leaks synthetic duplicate status') and ok
        if 'outcome_unknown' in enum: ok=fail(f'{schema_name} stores epistemic unknown as authoritative receipt') and ok
    inspect_enum=schemas['urn:l9:state:StateOperationInspectResult:1.0']['properties']['status']['enum']
    if inspect_enum != ['found','not_found']:
        ok=fail(f'operation inspect status must be found/not_found only, got {inspect_enum}') and ok
    list_req=schemas['urn:l9:state:StateListRequest:1.0']
    list_page=schemas['urn:l9:state:StateListPage:1.0']
    if 'consumer_ref' not in list_req.get('required',[]) or 'consumer_ref' not in list_page.get('required',[]):
        ok=fail('cold-resume list request/page must bind consumer_ref') and ok
    # Erased state cannot carry payload.
    erased={'contract_version':'1.0','state_ref':{'contract_version':'1.0','object_id':'o','scope_ref':'s','revision':1,'state_digest':'a'*64,'schema_ref':'urn:x','schema_digest':'b'*64,'lifecycle':'erased'},'payload_status':'erased','payload':{},'recorded_at':'2026-09-27T20:00:00Z','observed_at':'2026-09-27T20:00:00Z'}
    try:
        sch=schemas['urn:l9:state:StateReadResult:1.0']; Draft202012Validator(sch,registry=registry).validate(erased)
        ok=fail('StateReadResult permits payload when payload_status=erased') and ok
    except ValidationError: pass
    # Digest vectors: canonical bytes are shipped as authoritative conformance evidence.
    vectors=json.loads((ROOT/'fixtures/DIGEST_VECTORS.json').read_text())
    for vector in vectors.get('vectors',[]):
        canonical=vector.get('canonical_utf8','')
        observed=hashlib.sha256(canonical.encode('utf-8')).hexdigest()
        if observed != vector.get('sha256'):
            ok=fail(f"digest vector {vector.get('id')} SHA mismatch") and ok
        if vector.get('kind')=='state_digest': source=vector.get('input')
        elif vector.get('kind')=='request_digest': source={'action':vector.get('action'),'domain_request':vector.get('domain_request_without_operation_id')}
        else:
            ok=fail(f"unknown digest vector kind: {vector.get('kind')}") and ok; continue
        # These fixture values intentionally use the JSON subset whose Python compact/sorted encoding is byte-identical to RFC 8785 JCS.
        rendered=json.dumps(source,sort_keys=True,separators=(',',':'),ensure_ascii=False)
        if rendered != canonical:
            ok=fail(f"digest vector {vector.get('id')} canonical bytes drifted") and ok
    # Error taxonomy must use explicit string retry classes.
    reasons=yaml.safe_load((ROOT/'contracts/ERRORS_AND_REASON_CODES.yaml').read_text())
    allowed_retry=set(reasons.get('retry_classes',[]))
    for code,meta in reasons.get('reason_codes',{}).items():
        retry=meta.get('retry') if isinstance(meta,dict) else None
        if not isinstance(retry,str) or retry not in allowed_retry:
            ok=fail(f'reason code {code} has invalid retry class {retry!r}') and ok
    # Coding Agent handoff minimum closure and cross-repo boundary.
    h=yaml.safe_load((ROOT/'handoff/CODING_AGENT_HANDOFF.yaml').read_text())
    required={'contract_id','objective','target','in_scope','out_of_scope','locked_invariants','acceptance_criteria','forbidden_actions','validation_obligations','delivery_mode'}
    missing=required-set(h)
    if missing: ok=fail(f'handoff missing {sorted(missing)}') and ok
    if any('repo-template' in str(x).lower() for x in h.get('modification_scope',[])): ok=fail('handoff crosses repo boundary') and ok
    if 'state.checkpoint' in (ROOT/'API_CONTRACT.md').read_text(): ok=fail('retired state.checkpoint still public') and ok
    # Canonical journal is the outbox source; no state_outbox collection is allowed.
    mongo=(ROOT/'contracts/MONGODB_ADAPTER.md').read_text()
    if 'state_outbox' in mongo and 'no separate canonical `state_outbox` collection' not in mongo:
        ok=fail('canonical state_outbox collection reintroduced') and ok
    if ok:
        print(f'PASS: l9-state dev pack validation ({len(files)} files, {len(schemas)} schemas)')
        return 0
    return 1
if __name__=='__main__': raise SystemExit(main())
