# Validation and conformance plan

## Contract tests

- JSON Schema parse/ref closure and model parity.
- Extra/provider fields rejected.
- Canonical digest vectors stable across runs.
- Public models contain no Mongo/PyMongo/BSON/peer URL fields.
- Mutating action list exactly matches Gate runtime required-idempotency list.

## StateStore conformance suite

Run the same suite against in-process test store and Mongo adapter:

1. create revision 0;
2. same operation/same request returns the exact stored receipt byte-for-byte at the domain model boundary;
3. same operation/different request/action conflicts;
4. exactly one of two same-revision writers commits;
5. revision increments exactly once;
6. current projection equals immutable committed revision;
7. event and receipt exist iff state mutation exists;
8. historical named revision returns retained exact payload;
9. object ID cannot be recreated after tombstone/erase;
10. schema binding cannot change through transition;
11. no domain-specific payload kind changes behavior.

## Fencing suite

- simultaneous claim acquisition yields one holder;
- every new acquisition increments fence;
- renew preserves fence;
- release does not reset fence;
- paused holder after expiry/reassignment cannot write;
- application clock skew cannot extend lease authority;
- TTL cleanup is not used for fence truth.

## Operation ambiguity suite

Inject failures before write, before commit, during commit response, and after commit. A retried semantic operation must either return the exact stored receipt, prove no commit then execute once, or return a typed `StateProblem(OUTCOME_UNKNOWN)` without minting an authoritative receipt. It may never create two revisions.

## Journal/cursor suite

- journal sequence strictly increases within scope;
- different scopes have no ordering promise;
- foreign/modified cursor refused;
- consumer A cannot ack consumer B;
- ack is monotonic and idempotent under the same stored operation receipt;
- retention below cursor yields `resync_required`;
- cold resume list -> events catches create/update/tombstone races without requiring a second directory store.

## Retention suite

- tombstone increments revision and blocks active read;
- retained revision can be restored only while current state is tombstoned;
- restore creates a new revision and does not rewind;
- hard erasure scrubs payload but preserves identity/fence/replay tombstone;
- erased object cannot restore or recreate.

## Mongo integration proof

Use a real transaction-capable replica set. Validate primary failover/restart, majority/snapshot transaction behavior, index uniqueness, server-time claim predicates, and operation reconciliation. Change Streams are not required for v1 release.

## Gate round trip

From installed artifacts, prove a signed canonical Gate -> State -> Gate round trip for every registered action. Mutation action payload operation IDs must match transport idempotency keys. No State code performs peer HTTP.

## Release evidence

Bind exact repo head, lock digest, Gate_SDK resolved version/ref, Mongo server/driver versions, commands, exit codes, assertion counts, fault injections, skipped/blocked cases, and artifact hashes. Required live checks that cannot run are BLOCKED, not PASS.

- Cold-resume list cursors MUST bind the same `consumer_ref` as subsequent event/ack calls.

## Consumer authority suite

- default `consumer_ref` equals transport-derived principal;
- consumer_ref cannot impersonate another principal;
- explicitly authorized delegated consumer may read/ack its own cursor only;
- foreign consumer/list/event cursors fail closed without existence leakage.
