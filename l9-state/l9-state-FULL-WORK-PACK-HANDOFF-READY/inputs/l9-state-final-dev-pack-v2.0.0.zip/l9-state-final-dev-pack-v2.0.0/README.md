# L9 State Dev Pack v2.0.0

Status: **ARCHITECTURE_CONVERGED_PRE_CODE**  
Target: `Quantum-L9/l9-state`  
Execution owner after handoff: **L9 Coding Agent**  
Architecture owner: **L9 Global Architect (GAR)**

## North star

L9 State is the constellation's provider-neutral **mechanical durable-state authority**.
It stores opaque admitted payloads and owns only the mechanics required to make them durable and safely mutable:

`tenant-bound state + exact revision + durable operation identity + optional fenced claim + canonical committed event journal`

State does not understand WorkItem meaning, agent goals, memory meaning, evidence truth, next-action policy, routing, or provider query languages. Any domain that can express its durable state as an admitted schema contract over a JSON payload can use the same State primitive.

## Why this is leverage

One implementation supplies reusable mechanics for AgentOS work state, Semantic Compiler job state, formal-reasoning sessions, communication sessions, long-running execution checkpoints, and future nodes without copying persistence, CAS, idempotency, fencing, history, cold-resume, or recovery code.

## Final v2 architecture decisions

- Initial revision is `0`; every payload/lifecycle mutation increments by exactly one.
- Public mutations are **full replacement**, not a patch/query language.
- State payload schema binding is immutable for an object's v1 lifetime.
- Object identity is never reused within a tenant/scope, including after hard erasure.
- Every consequential mutation has one operation ID and one canonical request digest.
- State/request digests use RFC 8785 JCS + SHA-256 and must match the shipped digest vectors.
- For mutating Gate actions, transport `idempotency_key` equals domain `operation_id`.
- State mutation atomically commits current projection, immutable revision record, operation receipt, canonical event, and scope-local journal sequence.
- The canonical event journal is also the outbox source. There is no second canonical outbox truth.
- Claims are optional coordination. While a claim is active, protected writes require the exact claim ID and current fence. Lease expiry never resets fence lineage.
- MongoDB is the first private adapter, not the State contract.
- v1 uses pull-based `state.events` + `state.ack`; proactive push/change-stream wakeups are deferred until demand proves leverage.
- No project other than `l9-state` is in the Coding Agent execution scope.

## Pack map

Read in this order:

1. `AUTHORITY_MAP.yaml` - authority, supersession, and conflict disposition.
2. `IMPLEMENTATION_BLUEPRINT.yaml` - pre-code single ingress.
3. `ARCHITECTURE.md` - final component and authority model.
4. `BOUNDARY.yaml` and `INVARIANTS.md` - hard limits.
5. `contracts/` - exact public/domain/provider contracts.
6. `IMPLEMENTATION_PLAN.yaml` - bounded units.
7. `handoff/CODING_AGENT_HANDOFF.yaml` - first executable Coding Agent contract.
8. `RUNBOOK.md` - execution and GAR return protocol.
9. `TEST_PLAN.md` - proof obligations.

## External birth boundary

Repository/node birth is a separate project. This pack contains no birth-adapter implementation and grants Coding Agent no authority to edit any other repository. Before mutation, Coding Agent must bind the exact born/staging `l9-state` target and current revision. If that target does not exist, stop with `STATE_TARGET_NOT_BOUND`.
