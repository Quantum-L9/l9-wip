# ADR-007: Scope-local journal order and cold resume

**Status:** LOCKED

Events receive monotonic sequence only inside one tenant/scope. First list page captures an event resume cursor; consumer lists current state then catches up journal changes. This avoids a global transactional list snapshot and second directory store.
