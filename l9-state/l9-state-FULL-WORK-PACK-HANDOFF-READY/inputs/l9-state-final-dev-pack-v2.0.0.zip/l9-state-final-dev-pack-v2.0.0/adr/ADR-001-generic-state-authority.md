# ADR-001: Generic mechanical State authority

**Status:** LOCKED

State owns durable mechanics for opaque admitted schemas, not WorkItem/domain meaning. WorkItem remains a consumer schema, preserving prior capability while removing domain coupling.
