# ADR-006: Canonical journal is the outbox source

**Status:** LOCKED

One mutation creates one canonical StateTransitionEvent atomically. The journal is the durable publication source. A second canonical outbox record is rejected as duplicate truth. Push wakeups are deferred optimization.
