# ADR-010: Repository/node birth is a separate project

**Status:** LOCKED

L9 State consumes a born/admitted repository chassis but does not own, implement, or modify node-birth machinery. The Coding Agent State contract is one-repository-only.
