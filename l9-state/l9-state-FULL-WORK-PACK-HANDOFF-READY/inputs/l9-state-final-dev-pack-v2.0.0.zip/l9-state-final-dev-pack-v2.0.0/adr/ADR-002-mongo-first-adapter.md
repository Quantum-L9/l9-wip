# ADR-002: MongoDB is the first private adapter

**Status:** LOCKED_FIRST_ADAPTER

Use a transaction-capable MongoDB replica set through StateStorePort. Public contracts remain provider-neutral. PyMongo Async is preferred; Motor is not introduced. Replacement backends must pass owner-native conformance.
