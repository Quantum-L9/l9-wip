# ADR-003: Full replacement mutations only in v1

**Status:** LOCKED

Do not create a provider-neutral patch/query DSL. A transition supplies the complete next JSON payload plus expected revision/digest and optional active claim fence. This maximizes determinism and keeps provider mechanics private.
