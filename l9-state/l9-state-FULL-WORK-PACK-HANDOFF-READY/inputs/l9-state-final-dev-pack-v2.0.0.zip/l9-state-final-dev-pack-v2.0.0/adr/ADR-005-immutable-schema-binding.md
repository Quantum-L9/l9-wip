# ADR-005: Schema binding is immutable in v1

**Status:** LOCKED

Create binds `schema_ref` + `schema_digest`. Normal transitions may assert but never change that binding. Schema migration is an explicit future/governed surface, preventing State from inventing compatibility policy.
