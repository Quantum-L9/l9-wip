# ADR-009: Current projection plus immutable revision records

**Status:** LOCKED

Named-revision reads and retained restore require immutable revision records. Every state mutation atomically writes the immutable revision and the current projection. This is one State owner, not two semantic authorities.
