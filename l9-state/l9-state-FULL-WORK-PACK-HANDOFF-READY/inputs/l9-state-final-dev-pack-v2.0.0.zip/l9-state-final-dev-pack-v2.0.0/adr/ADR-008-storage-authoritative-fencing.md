# ADR-008: Storage-authoritative lease time and persistent fence lineage

**Status:** LOCKED

Lease validity is checked with storage-authoritative server time at commit. New acquisitions increment fence; renew keeps it; release/expiry never reset it. TTL cannot define lease authority.
