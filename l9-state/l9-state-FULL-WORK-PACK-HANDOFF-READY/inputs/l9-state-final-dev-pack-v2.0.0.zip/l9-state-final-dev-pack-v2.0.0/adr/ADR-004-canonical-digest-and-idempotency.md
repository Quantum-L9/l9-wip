# ADR-004: Canonical digest and one logical operation identity

**Status:** LOCKED

Canonical JSON uses RFC 8785 semantics and SHA-256. Scoped operation ID binds one action and request digest. For mutating Gate calls, transport idempotency key equals State operation ID. Transport hashes are not State operation identity.

Implementation guidance: use the admitted `rfc8785` package (prefer pinned 0.1.4) unless target repository policy requires a behaviorally equivalent admitted implementation. Do not hand-roll JCS without architecture reapproval.
