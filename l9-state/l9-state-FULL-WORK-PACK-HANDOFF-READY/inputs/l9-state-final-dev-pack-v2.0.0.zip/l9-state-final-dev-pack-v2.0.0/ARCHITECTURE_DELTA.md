# Architecture delta from source pack v1.1.0

## KEEP

- Opaque schema-bound State payloads.
- CAS revisions and durable operation identity.
- Monotonic fencing claims.
- MongoDB as first private adapter.
- Gate-only transport.
- Provider-neutral event recovery.
- Tombstone/retention/recovery responsibility.

## MODIFY

- Generalize the hydrated WorkItem description into schema-agnostic State; WorkItem becomes one consumer schema.
- Add immutable `state_revisions` so named historical revision reads are actually implementable.
- Make trusted tenant organization part of every internal key while keeping transport identity out of domain payload authority.
- Make v1 state mutation full replacement only.
- Make schema binding immutable for v1 object lifetime.
- Replace vague event ordering with a scope-local monotonic journal sequence.
- Replace list snapshot claims with a cold-resume protocol: capture event cursor -> list -> catch up events.
- Define storage-authoritative lease time and exact fence evolution.
- Define machine-stable reason codes and operation-reconciliation semantics.

## ADD

- Make semantic retries return the exact stored receipt; remove synthetic `duplicate` receipt status.
- Separate ambiguous infrastructure outcome from authoritative receipts: `StateProblem(OUTCOME_UNKNOWN)` + operation inspection.
- Bind cold-resume list/event cursors to the same authorized consumer identity.
- Make successful event-page cursors ackable even on the final page.
- Add exact ContractCatalogPort admission/validation boundary without making State own schema dialects.
- Add internal `hard_erase` store operation while keeping retention-policy ingress externally owned and deferred until STATE-04.

- RFC 8785 canonicalization + SHA-256 digest law.
- Typed StateStore/ContractCatalog boundary.
- Current Gate_SDK binding law: `idempotency_key == operation_id` for mutations.
- Hard-erasure identity tombstone rule and object-ID non-reuse.
- Retained restore semantics.
- Exact MongoDB collections/indexes/transaction concerns.
- Coding Agent execution handoff aligned to one active unit.

## RETIRE / DEFER

- State/node birth implementation remains a separate project and is never part of this handoff.

- Campaign-era prerequisite IDs.
- Domain-specific WorkItem branches in State core.
- Provider-neutral patch DSL in v1.
- Dedicated `state.checkpoint` action; checkpoint-shaped data uses ordinary admitted State objects.
- Separate canonical `state_outbox` truth. Canonical journal is the outbox source.
- Change Streams and proactive push delivery as v1 correctness requirements.
- Durable receipts for ordinary reads.
- Provider resume tokens in any public contract.
