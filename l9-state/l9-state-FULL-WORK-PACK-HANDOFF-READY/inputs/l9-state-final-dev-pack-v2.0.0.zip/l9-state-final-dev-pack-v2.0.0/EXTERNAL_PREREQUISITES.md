# External prerequisites - interface only

This file records prerequisites without importing their implementation into the State project.

## Node birth

A separate project will add the required node-birth adapter/profile to `Quantum-L9/l9-repo-template`.

This State pack:

- does not design that adapter;
- does not include files for that repository;
- grants Coding Agent no authority to edit it;
- requires only an observed admission/birth receipt or an explicitly authorized staging target before State mutation begins.

If the target is unavailable, Coding Agent stops with `STATE_TARGET_NOT_BOUND`.

## Gate_SDK

Current architecture observation: `Quantum-L9/Gate_SDK` exposes the `constellation-node-sdk` v1 family, including GateClient, handler registration, node runtime execution, and node registration. Bind the exact supported release/commit in the implementation baseline instead of coding against a remembered main SHA.

## MongoDB

Production State requires a transaction-capable replica set for the first adapter. Development unit tests may use the in-process conformance store, but release admission requires real replica-set fault/restart testing.
