# Provenance and live technical verification

Architecture convergence date: 2026-09-27.

## Supplied source

- `l9-state(1).zip`
- SHA-256: `f1f7656a943678d18b4a9bbb03c95905444cdb3c723265640285da9203808e6f`
- Source pack revision declared: 1.1.0

## Active L9 architecture hydration

Applied generic node laws for authority, provider boundaries, state/persistence, validation, evolution, and Gate-only transport. The earlier WorkItem-specific State description is generalized here: WorkItem remains a valid consumer schema, but not State core semantics.

## Gate_SDK live verification

Observed current repository `Quantum-L9/Gate_SDK` on 2026-09-27:

- package: `constellation-node-sdk`
- package version observed on current default branch: `1.1.0`
- Python requirement: `>=3.12`
- normal application egress: `GateClient.execute()`
- node runtime exposes handler registration/execution and node registration
- SDK law: one canonical TransportPacket, Gate-only egress, no hidden execution retry, domain payload opaque

Exact immutable release binding remains an implementation-baseline obligation because default-branch SHA is not release authority.

## MongoDB verification

Official MongoDB documentation verified at architecture time:

- current stable series reported as 8.3;
- transactions require transaction-level read concern; snapshot/majority semantics are available with majority commit;
- PyMongo Async is GA and is the replacement for Motor;
- `with_transaction()` may retry commit or callback, so State transaction callbacks must be re-entrant and external-effect-free;
- `$$NOW` is server-side current time usable in update pipelines;
- Change Stream resume depends on retained oplog history and is therefore unsuitable as canonical State cursor truth.

Exact server/driver patch versions remain lockfile/deployment decisions to be verified by Coding Agent.

## RFC 8785 implementation verification

PyPI verification at architecture time found `rfc8785` 0.1.4, published by Trail of Bits, as a pure-Python, no-runtime-dependency RFC 8785 implementation that emits UTF-8 bytes. STATE-01 prefers this admitted leaf dependency rather than a hand-written canonicalizer. Exact lockfile admission remains a Coding Agent baseline check.
