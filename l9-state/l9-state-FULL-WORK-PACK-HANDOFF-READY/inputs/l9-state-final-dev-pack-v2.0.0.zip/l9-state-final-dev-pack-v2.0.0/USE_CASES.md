# Leverage use cases

These are consumers, not branches in State code.

- **Semantic Compiler** - durable compilation job/config/result refs, revisions, checkpoints, exact retry receipts.
- **AgentOS / WorkItem** - WorkItem payload under an admitted WorkItem schema; State still does not understand its lifecycle.
- **Formal reasoning** - solver-session inputs/output refs and resumable state without embedding solver policy.
- **Communication plane** - durable session/channel coordination state without State becoming the communication router.
- **Program execution** - bounded execution facts/checkpoints without State becoming the scheduler or project ledger.
- **Future nodes** - any JSON-schema-bound durable state needing CAS, idempotency, fencing, history, cold resume, and recovery.

The reuse test is simple: if a proposed consumer needs State to understand its business meaning, the proposal is on the wrong side of the boundary.
