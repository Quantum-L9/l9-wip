# Security and trust boundary

## Trusted input

Only Gate_SDK-validated transport context may establish tenant organization, actor/delegation lineage, action, packet deadline, and transport idempotency.

State derives:

- `tenant_org_id = packet.tenant.org_id`;
- `principal_ref = packet.tenant.actor`.

`on_behalf_of`, `originator`, delegation lineage, and current policy evidence remain authorization context. They do not replace the executing actor as the claim/receipt principal.

## Untrusted input

All State domain payload fields, including scope/object IDs, schema refs, consumer refs, claim IDs, cursors, transition labels, and payload contents.

## Mandatory controls

- Tenant organization is inserted from transport into every persistence key.
- Domain models use strict extra-field rejection.
- Schema/retention refs resolve only through an admitted local/catalog contract, never caller-selected network URLs.
- No provider collection, operator, query, credential, server URL, or resume token field is accepted publicly.
- Claim holder/principal is server-derived from `packet.tenant.actor`.
- By default, `consumer_ref` MUST equal the transport-derived principal. A different consumer identity requires explicit `ScopeAuthorizationPort` authorization; naming another consumer in payload never grants cursor authority.
- Current authorization is checked before returning an old operation receipt.
- Payloads and private record bodies are redacted from logs by default.
- Public errors contain stable reason codes, not driver exception text or unauthorized existence detail.
- Request/payload/page sizes are bounded.
- The node never imports or controls peer credentials.

## Transport closure

Normal clients use a typed StateClient that delegates transport to `GateClient.execute`. The State node uses the Gate_SDK runtime for ingress. No direct peer HTTP is permitted.
