# Atomic commit contract

## State mutation CommitBundle

A successful create/transition/tombstone/restore/hard-erasure operation has exactly one commit boundary containing:

1. current object CAS/fence check;
2. scope journal sequence allocation;
3. immutable revision record;
4. current StateRecord projection;
5. canonical StateTransitionEvent;
6. immutable State operation receipt.

All six are visible or none are visible.

## Retry discipline

- Precompute generated receipt/event IDs once outside a transaction callback.
- Transaction callbacks contain database work only and may be re-entered by a driver under the same command/IDs.
- No Gate call, Evidence call, filesystem effect, model call, or external HTTP occurs inside the transaction.
- Driver transaction retry is an implementation retry of one semantic operation, never a new operation.
- On ambiguous commit completion, query OperationKey using durable majority semantics before returning a semantic result.
- If authoritative reconciliation cannot complete within the remaining request budget, return `StateProblem(OUTCOME_UNKNOWN)` carrying the operation ID. Never persist unknown as an authoritative operation receipt.
- A semantic retry that resolves an existing OperationKey returns the stored receipt unchanged. `duplicate` is not a receipt status.

## Claim mutation

Claim acquire/renew/release atomically changes the claim record and writes its operation receipt.

## Ack mutation

Consumer ack atomically advances the allowed consumer checkpoint and writes its operation receipt.

## Receipt evidence closure

Every durable mutation receipt, including state mutation, claim mutation, and consumer ack, records the transport-derived `principal_ref` plus an `authorization_ref` identifying the authorization decision/evidence used for that attempt. Payload fields cannot author either value.
