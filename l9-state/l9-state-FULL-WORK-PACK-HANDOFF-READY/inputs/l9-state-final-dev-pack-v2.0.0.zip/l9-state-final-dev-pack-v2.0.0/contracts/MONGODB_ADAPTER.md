# MongoDB first-adapter contract

MongoDB is a replaceable StateStorePort implementation.

## Baseline technology

- MongoDB transaction-capable replica set.
- PyMongo Async API (`AsyncMongoClient`), not Motor.
- Python 3.12+.
- Exact server/driver versions are resolved and locked by Coding Agent at repository baseline; broad floating runtime versions are not architecture authority.

## Collections

Private names may vary, but responsibilities may not:

1. `state_objects` - current projection and minimal identity tombstone.
2. `state_revisions` - immutable retained revision records.
3. `state_operations` - operation key, action, request digest, principal/policy evidence refs, immutable result receipt.
4. `state_events` - canonical StateTransitionEvents and scope-local journal sequence.
5. `state_claims` - active/inactive claim metadata and persistent highest fence lineage.
6. `state_consumer_cursors` - consumer-bound ack state.
7. `state_scope_counters` - scope-local next journal sequence.

There is no separate canonical `state_outbox` collection. Additional delivery-attempt metadata may exist later but cannot become event truth.

## Required unique indexes

- `(tenant_org_id, scope_ref, object_id)` on current objects.
- `(tenant_org_id, scope_ref, object_id, revision)` on revisions.
- `(tenant_org_id, scope_ref, operation_id)` on operations.
- `(tenant_org_id, scope_ref, journal_seq)` on events.
- `event_id` unique.
- `(tenant_org_id, scope_ref, object_id)` on claims.
- `(tenant_org_id, scope_ref, consumer_ref)` on consumer cursors.
- `(tenant_org_id, scope_ref)` on scope counters.

Add read indexes for object history and list filters only when explained by a query in the public contract.

## Transaction concerns

State mutation transaction uses primary read preference, snapshot read concern, and majority write concern. Majority/snapshot guarantees must be verified against the chosen Mongo version and deployment. Transaction callback performs database operations only.

## Authoritative lease time

Lease acquisition/renewal/write checks use Mongo server-side time in the atomic predicate/update (for example `$$NOW` semantics), not application wall clock as the authority.

## Ambiguous commit

A driver/network error after commit attempt does not imply failure. Reconcile `state_operations` under the original OperationKey. When authoritative reconciliation cannot complete within the remaining request budget, return a typed `StateProblem` with reason `OUTCOME_UNKNOWN`. Do not persist an unknown outcome as an authoritative receipt.

## Provider errors

Never leak PyMongo exceptions across the State service contract. Map them to stable State failure classes/reason codes while preserving the underlying exception for internal diagnostics.

## Change Streams

Not required in v1. Journal polling is canonical. A later change-stream adapter may wake a publisher, but oplog/resume-token behavior cannot redefine State event identity or cursor semantics.
