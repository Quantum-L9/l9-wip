# State model contract

## StateKey

Internal identity: `(tenant_org_id, scope_ref, object_id)`.
`tenant_org_id` is transport-derived and is never accepted from domain payload.

## StateRef

Public exact reference:

- `scope_ref`
- `object_id`
- `revision`
- `state_digest`
- `schema_ref`
- `schema_digest`
- `lifecycle`

## Lifecycle

`active -> tombstoned -> active (restore while retained)`  
`tombstoned -> erased`  
`erased` is terminal in v1.

Create establishes `active` revision 0. Object identity can never be created again after any lifecycle state has existed.

## Schema binding

`schema_ref` + `schema_digest` are immutable after create in v1. Transition requests carry their expected values as integrity assertions. A mismatch is conflict, not an implicit migration.

Schema migration is a future explicit capability or offline governed migration, never an accidental transition side effect.

## Payload mutation

v1 accepts complete replacement JSON objects only. There is no Mongo update document, JSONPath, JSON Patch, executable expression, or generic merge operation in the public contract.
