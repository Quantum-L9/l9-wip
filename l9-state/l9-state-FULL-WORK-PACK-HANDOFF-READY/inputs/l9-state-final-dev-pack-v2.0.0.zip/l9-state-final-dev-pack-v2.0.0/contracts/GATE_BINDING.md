# Gate_SDK binding contract

Current verified SDK family at architecture convergence: `constellation-node-sdk` v1.x, observed package version `1.1.0`. Resolve and bind the exact current supported release at implementation baseline.

## Ingress

Use Gate_SDK runtime primitives and handler registration. Do not implement FastAPI transport/auth/signature plumbing in State.

The binding layer receives a validated TransportPacket and derives a CallerContext from trusted packet fields. `tenant_org_id` comes from `packet.tenant.org_id`; `principal_ref` comes from `packet.tenant.actor`. `on_behalf_of`, `originator`, and delegation lineage remain authorization evidence. Domain payload attempts to supply tenant/principal/actor authority are rejected as invalid fields.

## Idempotency closure

For each mutating action, configure Gate_SDK runtime to require transport idempotency and enforce:

`packet.header.idempotency_key == request.operation_id`

No payload hash substitutes for logical operation identity.

## Action registration

Register only actions whose implementation and conformance tests exist at the current revision. Do not advertise roadmap actions as supported.

Final API family:

Reads:
- `state.get`
- `state.history`
- `state.events`
- `state.list`
- `state.operation.inspect`

Mutations:
- `state.create`
- `state.transition`
- `state.claim`
- `state.renew`
- `state.release`
- `state.ack`
- `state.tombstone`
- `state.restore`

There is no dedicated `state.checkpoint` action in v1. A checkpoint is an ordinary State object under an admitted checkpoint schema.

## Outbound

v1 correctness does not require proactive outbound State publication. If a later publisher is admitted, it must use `GateClient.execute()` and the canonical State event ID as its semantic idempotency input. No peer address is accepted anywhere in State.
