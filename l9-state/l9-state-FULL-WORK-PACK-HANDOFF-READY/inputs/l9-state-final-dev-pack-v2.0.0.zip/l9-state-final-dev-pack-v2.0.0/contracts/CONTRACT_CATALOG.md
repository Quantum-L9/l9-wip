# Contract catalog consumption boundary

State persists schema-bound payloads but does not own domain schema meaning or legal/business retention policy.

## ContractCatalogPort

The port is an admission/validation boundary, not a generic document resolver.

Required semantic operations:

1. `validate_state_payload(schema_ref, schema_digest, payload)`
   - resolves only from the deployment's admitted contract catalog;
   - verifies the resolved contract bytes match `schema_digest`;
   - validates the complete JSON payload;
   - returns a typed admitted/refused verdict without leaking catalog/provider internals.
2. `assert_retention_contract(retention_policy_ref, retention_policy_digest)`
   - verifies exact ref+digest is admitted for persistence;
   - returns an opaque admission handle/evidence ref;
   - does not let State invent policy values.

## Core prohibitions

State core MUST NOT:

- resolve caller-selected URLs;
- assume a public network registry;
- infer a schema from payload shape;
- rewrite/adapt a payload to make validation pass;
- make JSON Schema dialect or validator APIs part of the public State contract;
- invent retention periods, legal holds, deletion rules, or restore eligibility.

## First conformance implementation

STATE-01 may use an in-process/configured catalog fixture. It must demonstrate at least one admitted schema, exact digest mismatch failure, payload validation failure, and retention-contract admission failure.

A deployment catalog may use JSON Schema Draft 2020-12 internally, but that is adapter detail. Replacing the catalog implementation cannot change State public semantics.

## Retention execution boundary

`retention_policy_ref + retention_policy_digest` are immutable object metadata established at create. The detailed policy decision interface required to execute hard-erasure schedules is a separately owned external contract that MUST be bound before STATE-04 activation. Its absence does not block STATE-01 through STATE-03.
