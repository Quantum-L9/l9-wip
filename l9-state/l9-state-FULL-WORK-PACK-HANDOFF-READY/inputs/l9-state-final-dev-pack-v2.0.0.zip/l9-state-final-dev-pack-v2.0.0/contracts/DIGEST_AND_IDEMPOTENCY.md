# Digest and idempotency contract

## Canonical serialization

State-owned semantic digests use **RFC 8785 JSON Canonicalization Scheme (JCS)** bytes encoded as UTF-8 and SHA-256 rendered as 64 lowercase hexadecimal characters.

Do not substitute BSON encoding, Python `repr`, provider serialization, insertion-order JSON, `TransportPacket.transport_hash`, or a payload-only hash.

## State digest

For a retained revision, calculate `state_digest` from exactly this semantic object:

```json
{
  "schema_ref": "...",
  "schema_digest": "<64 lowercase hex>",
  "lifecycle": "active|tombstoned|erased",
  "payload": {}
}
```

For lifecycle `erased`, `payload` is JSON `null`. For all retained payload-bearing revisions, `payload` is the complete admitted JSON object. Revision number, object ID, tenant, scope, timestamps, claim state, provider IDs, and event metadata are deliberately excluded. The digest describes the semantic state value, not its storage address.

## Request digest

For every consequential mutation, calculate `request_digest` from:

```json
{
  "action": "state.<mutation>",
  "domain_request": { ...request fields except operation_id... }
}
```

Remove exactly `operation_id` before canonicalization. Do not remove CAS expectations, claim/fence data, transition labels, policy refs, or other semantic request fields.

`operation_id` is the durable lookup key. `action + request_digest` is the immutable semantic binding of that operation ID.

## Retry law

Within `(tenant_org_id, scope_ref, operation_id)`:

- no stored operation: execute the semantic operation once;
- stored action and request digest equal the incoming values: reauthorize current access, then return the **exact stored receipt unchanged**;
- stored action or request digest differs: return `IDEMPOTENCY_COLLISION` with no effect;
- transport outcome is ambiguous: inspect durable operation state before any semantic retry.

There is no `duplicate` receipt status. A retry does not mint another receipt merely to describe that it was a retry.

## Transport closure

For every mutating Gate action:

`packet.header.idempotency_key == request.operation_id`

A mismatch is rejected before State mutation.

## Conformance vectors

`fixtures/DIGEST_VECTORS.json` is canonical test evidence. Any implementation whose canonical bytes or SHA-256 output differs from those vectors is non-conformant.
