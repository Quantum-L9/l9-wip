# Claims and fencing

Claims prevent a paused old worker from continuing after coordination authority has moved.

## Acquire

Input: StateKey, expected revision, requested TTL, operation ID. Holder is derived from trusted caller context.

Success requires no active unexpired claim. It increments `fencing_token` by exactly one and creates a new `claim_id`.

## Renew

Requires exact StateKey, claim ID, current fencing token, current holder, nonexpired claim, and positive capped TTL. Renewal preserves the fencing token.

## Release

Requires exact StateKey, claim ID, current fencing token, and current holder. Release makes the claim inactive but does not decrement/delete fence lineage.

## Expiry

Expiry is evaluated at authoritative storage commit time. For MongoDB, use server-side time semantics such as `$$NOW` in the conditional operation. Application wall-clock prechecks may improve errors but cannot authorize a write.

## Interaction with state mutation

- If an unexpired active claim exists, payload/lifecycle mutations must present its exact claim ID and fence.
- If a claim is supplied but is stale, expired, released, or superseded, mutation is refused.
- If no active claim exists, CAS mutation can proceed without a claim.

Claims coordinate mutation and never grant domain/business authority.
