# Event journal, cursors, ack, and cold resume

## Canonical event

Every payload/lifecycle mutation emits one StateTransitionEvent in the same transaction. Events contain safe metadata and StateRefs, not unrestricted payload copies.

A scope-local `journal_seq` is strictly monotonic. No global order is promised across scopes.

Event kinds:

- created
- transitioned
- tombstoned
- restored
- erased

## Cursor law

`consumer_ref` is a logical durable consumer identity, but it is not self-authorizing. By default it MUST equal the transport-derived principal. A different value requires explicit authorization from `ScopeAuthorizationPort`.

A cursor is opaque to the client and binds at least:

- tenant organization;
- scope;
- consumer;
- journal position;
- cursor format/version.

It may be encoded/signed or server-referenced privately. It must not contain a Mongo resume token as public semantics.

Cursor types are purpose-bound. An event cursor cannot be reused as a list/history cursor, and vice versa.

A `state.list` request MUST include the `consumer_ref` that will perform catch-up. Its list cursor binds tenant organization, scope, consumer, schema filters, lifecycle filter, page position, and the single `resume_event_cursor` captured for the enumeration. Later list pages MUST carry that same resume-event position rather than taking a new snapshot point.

## state.events

- no cursor: resume from the consumer's durable ack if one exists, otherwise earliest retained event;
- cursor: resume strictly after its committed journal position;
- every successful (`complete` or `bounded`) page returns an ackable `next_cursor` representing the position after the returned events, including an empty/final page;
- if requested position is older than retained history, return `resync_required` with no events, no ackable next cursor, and the retained lower bound.

## state.ack

Ack means the consumer has durably processed all events represented by the issued cursor. Ack is monotonic, idempotent, consumer-bound, scope-bound, and cannot jump to an unissued/foreign cursor.

## Cold resume

`state.list` first page captures and returns `resume_event_cursor`. The same resume cursor is carried through subsequent list pages. After enumeration, consume `state.events` from that cursor. If retention invalidates it before catch-up, restart enumeration.

This protocol allows a correct resume without a globally transactional directory snapshot.
