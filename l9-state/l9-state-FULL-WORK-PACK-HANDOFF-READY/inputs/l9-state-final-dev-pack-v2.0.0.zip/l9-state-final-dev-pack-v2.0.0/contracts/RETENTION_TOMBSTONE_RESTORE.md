# Retention, tombstone, hard erasure, and restore

State executes retention mechanics from admitted retention contracts. It does not invent legal/business retention policy.

## Tombstone

A public tombstone is a CAS state mutation. It creates a new revision with lifecycle `tombstoned` and a canonical event. Ordinary active reads stop returning it.

## Historical payload

Revision payloads may remain retained after tombstone according to the admitted retention contract. Event/receipt metadata is retained separately from payload bytes.

## Restore

`state.restore` is allowed only when:

- current lifecycle is `tombstoned`;
- caller names a retained source revision of the same object;
- schema binding matches the immutable object schema;
- CAS and any active fence pass;
- the retained payload still exists.

Restore creates a new active revision; it never rewinds the revision counter.

## Hard erasure

Hard erasure is an internal retention operation, not a generic client delete. It may remove retained payload bytes but preserves a minimal State identity tombstone: object identity, highest revision, highest fence, lifecycle `erased`, and the metadata necessary to prevent idempotency/ABA violations.

Restore from `erased` is refused in v1. Object ID reuse is always refused.

## TTL prohibition

Do not use TTL indexes to define lease expiry, operation-receipt validity, tombstone semantics, or hard erasure. Retention execution must be explicit and testable.
