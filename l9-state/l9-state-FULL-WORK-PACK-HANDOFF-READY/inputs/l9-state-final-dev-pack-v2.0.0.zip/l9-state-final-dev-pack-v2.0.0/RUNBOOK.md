# Architecture-to-Coding-Agent runbook

This is an implementation handoff runbook, not a production operations runbook.

## 1. Hydrate once

Read `AUTHORITY_MAP.yaml`, then `IMPLEMENTATION_BLUEPRINT.yaml`. Treat raw source material as evidence only after this point. Load deeper contracts only for the active implementation unit.

## 2. Bind before mutation

Coding Agent must bind:

- the exact `Quantum-L9/l9-state` repository/worktree and immutable base revision;
- current repository-local instructions and validation entrypoints;
- an observed node-birth admission/staging target supplied by the separate birth project;
- the exact supported Gate_SDK v1 release actually used by the target.

If any material binding is unresolved, stop the affected mutation. Do not compensate by editing another repository.

## 3. Execute one contract at a time

Start with `handoff/CODING_AGENT_HANDOFF.yaml` (`STATE-01`). Do not implement later roadmap units because their architecture is documented.

Coding Agent has implementation-detail sovereignty only inside the locked semantic envelope. Escalate public contract, authority, dependency, provider, or invariant changes to GAR.

## 4. Validate in dependency order

Run the narrowest checks that can falsify the current repair first, then repository-native mandatory gates. Every mutation must trace to the active contract and every acceptance claim to observed evidence.

For STATE-01 specifically prove:

- digest vectors exactly;
- create revision `0`;
- full-replacement CAS transition;
- exact stored receipt on semantic retry;
- idempotency collision causes no effect;
- current and retained revision read;
- operation inspection without replay;
- Gate handler round trips for only implemented actions;
- no provider syntax or peer transport leaks into public/domain surfaces.

## 5. Return to GAR

After STATE-01, return the exact final revision, diff, checks, execution receipt, unresolved unknowns, and any requested architecture decision. Do not activate STATE-02 until GAR accepts the exact evidence-bound result.

## 6. Project boundary

The node-birth adapter/profile is a separate project. This runbook contains no authority to design, implement, patch, or publish it.
