# Public capability contract v1

Public payload schemas are in `contracts/schemas/`. Transport fields belong to Gate_SDK and are intentionally absent from these schemas.

| Action | Effect | Contract |
|---|---|---|
| `state.create` | write | Create revision 0 for a never-used StateKey. |
| `state.get` | read | Read current or named retained revision. |
| `state.transition` | write | Full replacement under revision+digest CAS and active-fence rule. |
| `state.history` | read | Read canonical event history for one object with bounded coverage. |
| `state.claim` | write | Acquire one active claim and increment fence. |
| `state.renew` | write | Extend current holder's unexpired claim without changing fence. |
| `state.release` | write | Release exact current claim while retaining fence lineage. |
| `state.events` | read | Read committed scope journal through State-issued cursor. |
| `state.ack` | write | Monotonically persist consumer progress for an issued cursor. |
| `state.tombstone` | write | Revisioned lifecycle transition to tombstoned. |
| `state.restore` | write | Restore retained prior revision into a new active revision. |
| `state.list` | read | Enumerate current StateRefs and supply cold-resume event cursor. |
| `state.operation.inspect` | read | Resolve authoritative mutation receipt without replay. |

## Common write law

Every write:

1. derives tenant/principal from validated transport;
2. requires payload `operation_id` equal to transport `idempotency_key`;
3. computes canonical request digest;
4. reauthorizes the current caller before revealing an already-stored operation receipt;
5. commits its owned state and operation receipt atomically;
6. never performs an external effect inside the transaction.

## Read law

Reads are bounded observations. They do not create durable operation receipts. Responses expose coverage/retention state where relevant and never report truncated history as complete.

## Cold-resume identity

Cold-resume list requests carry the eventual event `consumer_ref`. State binds list pagination and the captured `resume_event_cursor` to tenant, scope, consumer, and list filters; a cursor is not transferable across consumers or purposes.

## Ambiguous outcome

A transport/storage ambiguity is not a durable receipt state. Return `StateProblem` with `OUTCOME_UNKNOWN` and the operation ID. Operation inspection returns only `found` or `not_found` when it can answer authoritatively; storage inability is a typed problem, never a fabricated inspect result.
