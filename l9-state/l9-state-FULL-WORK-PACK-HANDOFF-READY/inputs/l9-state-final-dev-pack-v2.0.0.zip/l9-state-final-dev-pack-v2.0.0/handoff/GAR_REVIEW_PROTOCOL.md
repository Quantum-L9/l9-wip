# GAR -> Coding Agent review loop

This pack does not authorize Coding Agent to execute the whole roadmap as one undifferentiated change.

1. Coding Agent executes only `STATE-01` from `CODING_AGENT_HANDOFF.yaml`.
2. It returns exact revision, diff scope, validation evidence, acceptance matrix, unknowns, and discovered architecture conflicts.
3. GAR reviews the exact implementation evidence against this dev pack.
4. GAR returns `ACCEPT`, `REWORK`, or a new bounded next execution contract.
5. `STATE-02` does not become active merely because STATE-01 code exists.

Implementation-detail sovereignty stays with Coding Agent; architecture changes stay with GAR/human authority.
